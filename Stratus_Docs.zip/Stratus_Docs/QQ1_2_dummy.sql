SELECT conv_det.[Conversation_Identifier] as Conversation_ID,
    conv_det.[Conversation_Start_Date_Time] as Conversation_Start_Time,
    conv_det.[Conversation_End_Date_Time] as Conversation_End_Time,
    conv_det.[Originating_Direction] as  Direction,
                --session.[Dialed_Number_Identification_Service] AS DNIS,
				cast(session.[Dialed_Number_Identification_Service] as bigint)  AS DNIS,
    MIN(conv_session.[Media_Type]) Media_Type,
                conv_part.[Purpose] Participant_Purpose,
                (CASE WHEN conv_part.[Purpose] = 'Customer' THEN conv_part.[Participant_Name]
                       WHEN conv_part.[Purpose] = 'Acd' THEN conv_part.[Participant_Name] 
                       ELSE user1.[Name] END) AS Participant_Name,     
                CASE WHEN conv_part.[Purpose] = 'Agent' THEN user1.[Divisionid] WHEN conv_part.[Purpose] = 'Acd' THEN queue1.[Division_Identifier]  END As Division_ID,
                CASE WHEN conv_part.[Purpose] = 'Agent' THEN user1.[Divisionname] WHEN conv_part.[Purpose] = 'Acd' THEN queue1.[Division_Name] END As Division_Name,
				
                --REMOVE--MAX(CASE WHEN metric.name = 'nTransferred' THEN metric.value END) AS Transfer,
				ISNULL(CAST(MAX(CASE WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nTransferred' THEN metric.[Value1] END) as decimal(38,0)),0) AS Transfer,
				
                --REMOVE--MAX(CASE WHEN metric.name = 'nBlindTransferred' THEN metric.value END) AS Blind_Transfered,
				MAX(CASE WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nBlindTransferred' THEN metric.[Value1] END) AS Blind_Transfered,
				
				
                --REMOVE--MAX(CASE WHEN metric.name = 'nConsult' THEN metric.value END) AS Consult,
				MAX(CASE WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nConsult' THEN metric.[Value1] END) AS Consult,
				
                MAX(CASE WHEN metric.Name1 = 'nConsultTransferred' THEN metric.Value1 END) AS Consult_Transfered,
				MAX(CASE WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nConsultTransferred' THEN metric.[Value1] END) AS Consult_Transfered,
				
                --REMOVE--MAX(CASE WHEN metric.name = 'tAnswered' THEN 1 ELSE 0 END) AS Accepted,
				ISNULL(MAX(CASE WHEN metric.[Name1] = 'tAnswered' THEN 1 ELSE 0 END),0) AS Accepted,
				
				
                --REMOVE--MAX(CASE WHEN metric.name = 'nConsultTransferred' and metric.value=1 THEN 'Consult'
                --REMOVE--WHEN metric.name = 'nBlindTransferred' and metric.value=1 then 'Blind' END) as Transfer_Type,
				
				MAX(CASE WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nConsultTransferred' and metric.[Value1]=1 THEN 'Consult'
                          WHEN conv_part.[Participant_Identifier] = metric.[Participant_Identifier] and metric.[Name1] = 'nBlindTransferred' and metric.Value1=1 then 'Blind' END) AS Transfer_Type,
				
                --segment."segmentType" segmentType,
                ----ASK--segment.Segment_Start as Segment_Start_Time,
                ---ASK--segment.Segment_End as Segment_End_Time,
                --REMOVE--MAX(CASE WHEN segment.segmenttype = 'Interact' THEN segment.disconnecttype END) AS Disconnect_Type,
				MAX(CASE WHEN segment.[Segment_Type] = 'Interact' THEN segment.[Disconnect_Type] END) AS Disconnect_Type,
                transfert.[Transfer_From_Target_Type] as Transfer_from_Target_Type,
                conv_part.[Participant_Identifier] as Participant_ID,
                cast(conv_det.[Conversation_Start_Date_Time] as date) as [Date]
FROM [global_telephony].[Fact_Telephony_CONVERSATION_DETAILS] conv_det
LEFT JOIN [global_telephony].[Dim_Telephony_DIMENSION_PARTICIPANT] conv_part ON conv_det.[Conversation_Identifier] = conv_part.[Conversation_Identifier]
LEFT JOIN [global_telephony].[Dim_Telephony_DIMENSION_SESSION] conv_session  ON conv_session.[Conversation_Identifier] = conv_det.[Conversation_Identifier] 
AND conv_session.[Participant_Identifier] = conv_part.[Participant_Identifier]
LEFT OUTER join [global_telephony].[Dim_Telephony_USER] user1  ON conv_part.User_Identifier = user1.[Id]
LEFT OUTER JOIN (select [Division_Identifier],[Division_Name],Name from [global_telephony].[Dim_Telephony_QUEUE] with (nolock)) queue1 ON conv_part.[Participant_Name] = queue1.[Name]
LEFT OUTER JOIN [global_telephony].[Dim_Telephony_DIMENSION_METRIC] metric  
ON  conv_det.[Conversation_Identifier] = metric.[Conversation_Identifier] 
 AND conv_part.[Participant_Identifier] = metric.[Participant_Identifier] 


--REMOVE/ASK--LEFT OUTER JOIN prodathena_hpinc_global.dimension_participant_attribute attribute ON  conv_det.conversationid = attribute.conversationid AND conv_part.participantid = attribute.participantid AND attribute."dt" = '2023-03-10'

LEFT OUTER JOIN [global_telephony].[Dim_Telephony_DIMENSION_PARTICIPANT_ATTRIBUTE] attribute  ON conv_det.[Conversation_Identifier] = attribute.[Conversation_Identifier] AND conv_part.[Participant_Identifier] = attribute.[Participant_Identifier] AND attribute.[Date] = conv_det.[Date]


LEFT OUTER JOIN [global_telephony].[Dim_Telephony_DIMENSION_SESSION] session  ON conv_det.[Conversation_Identifier] = session.[Conversation_Identifier] AND conv_part.[Participant_Identifier] = session.[Participant_Identifier] 
LEFT OUTER JOIN [global_telephony].[Dim_Telephony_DIMENSION_SEGMENT] segment ON conv_det.[Conversation_Identifier] = segment.[Conversation_Identifier] AND conv_part.[Participant_Identifier] = segment.[Participant_Identifier]


LEFT OUTER JOIN [global_telephony].[Fact_Telephony_TRANSFERS] transfert ON conv_det.[Conversation_Identifier] = transfert.[Conversation_Identifier]
WHERE conv_part.Purpose in ('Agent','Customer','Acd')
--AND conv_det.conversationid in ('2396f596-65cd-4cab-9d6a-c34537441b08','00001c1e-a7e5-4535-a40f-150482b3ed92','fe4d418f-9f89-43a7-94a8-2b47d35d605e','d21f8011-1584-4252-a46b-f66f7766dbab')
--AND conv_det.dt='2023-04-28'
AND segment.[Segment_Type] = 'Interact' AND segment.[Disconnect_Type] != ''
GROUP BY conv_det.[Conversation_Identifier], conv_part.[Participant_Identifier], conv_det.[Conversation_Start_Date_Time], 
conv_det.[Conversation_End_Date_Time], conv_det.[Originating_Direction], conv_part.[Purpose], conv_part.[Participant_Name], 
user1.[Name],session.[Dialed_Number_Identification_Service],session.[Automatic_Number_Identification], transfert.[Transfer_From_Target_Type], segment.[Segment_Start], segment.[Segment_End], segment.[Segment_Type],
conv_part.Purpose,user1.Divisionid,queue1.[Division_Identifier],user1.[Divisionname],queue1.[Division_Name],conv_det.[Date]
ORDER BY conv_det.[Conversation_Start_Date_Time] ASC, segment.[Segment_Start] ASC
